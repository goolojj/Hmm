package com.crimsongold.gui;

import com.crimsongold.CrimsonGoldClient;
import com.crimsongold.config.ClientConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;

public class CrimsonClickGui extends Screen {
    private enum Category { ALL, PVP, VISUALS, HUD }

    private record ModuleCard(String name, String desc, Category cat, BooleanSupplier getter, Runnable toggler, int x, int y, int w, int h) {}

    private Category activeCategory = Category.ALL;
    private final List<ModuleCard> cards = new ArrayList<>();
    private final List<int[]> tabBounds = new ArrayList<>();

    private int winX, winY, winW, winH;
    private int closeX, closeY, closeW, closeH;
    private int blurBtnX, blurBtnY, blurBtnW, blurBtnH;

    public CrimsonClickGui() {
        super(Text.literal("CrimsonGold Client"));
    }

    @Override
    protected void init() {
        cards.clear();
        tabBounds.clear();

        winW = Math.min(460, this.width - 24);
        winH = Math.min(270, this.height - 24);
        winX = (this.width - winW) / 2;
        winY = (this.height - winH) / 2;

        ClientConfig cfg = CrimsonGoldClient.CONFIG;

        // Left Sidebar Tabs
        int sideW = 92;
        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            int tx = winX + 10;
            int ty = winY + 44 + i * 28;
            int tw = sideW - 20;
            int th = 22;
            tabBounds.add(new int[]{tx, ty, tw, th});
            Category c = cats[i];
            this.addDrawableChild(ButtonWidget.builder(Text.empty(), b -> {
                activeCategory = c;
                this.clearAndInit();
            }).dimensions(tx, ty, tw, th).build());
        }

        // Motion Blur Strength Cycle Button in Sidebar
        blurBtnX = winX + 10;
        blurBtnY = winY + winH - 58;
        blurBtnW = sideW - 20;
        blurBtnH = 20;
        this.addDrawableChild(ButtonWidget.builder(Text.empty(), b -> {
            cfg.motionBlurLevel = (cfg.motionBlurLevel % 3) + 1;
            cfg.save();
        }).dimensions(blurBtnX, blurBtnY, blurBtnW, blurBtnH).build());

        // Close Button in Sidebar Bottom
        closeX = winX + 10;
        closeY = winY + winH - 32;
        closeW = sideW - 20;
        closeH = 20;
        this.addDrawableChild(ButtonWidget.builder(Text.empty(), b -> {
            cfg.save();
            this.close();
        }).dimensions(closeX, closeY, closeW, closeH).build());

        // Build Module List
        List<ModuleCard> all = new ArrayList<>();
        all.add(new ModuleCard("Target HUD", "HP & Hitbox Distance", Category.PVP, () -> cfg.hitboxEnabled, () -> { cfg.hitboxEnabled = !cfg.hitboxEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModuleCard("Entity Outline", "Glow Targets (<32m)", Category.VISUALS, () -> cfg.outlineEnabled, () -> { cfg.outlineEnabled = !cfg.outlineEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModuleCard("FPS Boost", "Disable Heavy Shadows", Category.VISUALS, () -> cfg.fpsBoostEnabled, () -> { cfg.fpsBoostEnabled = !cfg.fpsBoostEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModuleCard("Motion Blur", "Smooth Turn Blur", Category.VISUALS, () -> cfg.motionBlurEnabled, () -> { cfg.motionBlurEnabled = !cfg.motionBlurEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModuleCard("ToggleSprint", "Auto Sprint Forward", Category.PVP, () -> cfg.toggleSprintEnabled, () -> { cfg.toggleSprintEnabled = !cfg.toggleSprintEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModuleCard("NoHurtCam", "Zero Damage Shake", Category.PVP, () -> cfg.noHurtCamEnabled, () -> { cfg.noHurtCamEnabled = !cfg.noHurtCamEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModuleCard("Fullbright", "Max Cave Brightness", Category.VISUALS, () -> cfg.fullbrightEnabled, () -> { cfg.fullbrightEnabled = !cfg.fullbrightEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModuleCard("Keystrokes", "WASD + Space + CPS", Category.HUD, () -> cfg.keystrokesEnabled, () -> { cfg.keystrokesEnabled = !cfg.keystrokesEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModuleCard("Armor HUD", "Equipped Gear Display", Category.HUD, () -> cfg.armorHudEnabled, () -> { cfg.armorHudEnabled = !cfg.armorHudEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModuleCard("CPS & Info", "FPS / Coords / CPS", Category.HUD, () -> cfg.cpsCounterEnabled, () -> { cfg.cpsCounterEnabled = !cfg.cpsCounterEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModuleCard("Sprint Pill", "Bottom Sprint Badge", Category.HUD, () -> cfg.sprintPillEnabled, () -> { cfg.sprintPillEnabled = !cfg.sprintPillEnabled; cfg.save(); }, 0, 0, 0, 0));
        all.add(new ModuleCard("Master HUD", "Show All Overlays", Category.HUD, () -> cfg.hudEnabled, () -> { cfg.hudEnabled = !cfg.hudEnabled; cfg.save(); }, 0, 0, 0, 0));

        int gridX = winX + sideW + 10;
        int gridY = winY + 42;
        int availW = winW - sideW - 20;
        int cardW = (availW - 8) / 2;
        int cardH = 32;
        int idx = 0;

        for (ModuleCard m : all) {
            if (activeCategory != Category.ALL && m.cat() != activeCategory) continue;
            int col = idx % 2;
            int row = idx / 2;
            int cx = gridX + col * (cardW + 8);
            int cy = gridY + row * (cardH + 6);
            if (cy + cardH > winY + winH - 8) break;
            ModuleCard placed = new ModuleCard(m.name(), m.desc(), m.cat(), m.getter(), m.toggler(), cx, cy, cardW, cardH);
            cards.add(placed);
            this.addDrawableChild(ButtonWidget.builder(Text.empty(), b -> placed.toggler().run())
                    .dimensions(cx, cy, cardW, cardH).build());
            idx++;
        }
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // Dimmed frosted backdrop
        ctx.fill(0, 0, this.width, this.height, 0x7705040A);

        // Main Feather-Style Dark Glass Window
        ctx.fill(winX, winY, winX + winW, winY + winH, 0xEA0C0B12);
        drawBorder(ctx, winX, winY, winW, winH, 0xFFFFD466);
        drawBorder(ctx, winX + 1, winY + 1, winW - 2, winH - 2, 0xFFC41E44);

        // Top Header Bar
        ctx.fill(winX + 2, winY + 2, winX + winW - 2, winY + 32, 0xFF150C14);
        ctx.fill(winX + 2, winY + 32, winX + winW - 2, winY + 33, 0xFFC41E44);
        ctx.drawTextWithShadow(this.textRenderer, "§6§lCRIMSON§c§lGOLD §fCLIENT", winX + 12, winY + 13, 0xFFFFFF);
        String ver = "§71.21.11  •  §6FEATHER UI";
        ctx.drawTextWithShadow(this.textRenderer, ver, winX + winW - this.textRenderer.getWidth(ver) - 12, winY + 13, 0xFFFFFF);

        // Left Sidebar Divider
        int sideW = 92;
        ctx.fill(winX + sideW, winY + 33, winX + sideW + 1, winY + winH - 2, 0x66C41E44);

        // Render Sidebar Tabs
        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            int[] b = tabBounds.get(i);
            boolean active = (cats[i] == activeCategory);
            boolean hov = isHover(mouseX, mouseY, b[0], b[1], b[2], b[3]);
            int bg = active ? 0xDD381020 : (hov ? 0xAA20141C : 0x66121018);
            int brd = active ? 0xFFFFD466 : (hov ? 0xFFC41E44 : 0x44FFFFFF);
            ctx.fill(b[0], b[1], b[0] + b[2], b[1] + b[3], bg);
            drawBorder(ctx, b[0], b[1], b[2], b[3], brd);
            if (active) ctx.fill(b[0], b[1] + 3, b[0] + 2, b[1] + b[3] - 3, 0xFFFFD466);
            String label = cats[i].name();
            int tw = this.textRenderer.getWidth(label);
            ctx.drawTextWithShadow(this.textRenderer, label, b[0] + (b[2] - tw) / 2, b[1] + 7, active ? 0xFFD466 : 0xCCCCCC);
        }

        // Render Blur Level Button
        String blurLvl = switch (CrimsonGoldClient.CONFIG.motionBlurLevel) {
            case 1 -> "Blur: LOW";
            case 3 -> "Blur: HIGH";
            default -> "Blur: MED";
        };
        boolean blurHov = isHover(mouseX, mouseY, blurBtnX, blurBtnY, blurBtnW, blurBtnH);
        ctx.fill(blurBtnX, blurBtnY, blurBtnX + blurBtnW, blurBtnY + blurBtnH, blurHov ? 0xCC2A1520 : 0xAA14111A);
        drawBorder(ctx, blurBtnX, blurBtnY, blurBtnW, blurBtnH, 0xAAFFD466);
        ctx.drawCenteredTextWithShadow(this.textRenderer, blurLvl, blurBtnX + blurBtnW / 2, blurBtnY + 6, 0xFFD466);

        // Render Close Button
        boolean closeHov = isHover(mouseX, mouseY, closeX, closeY, closeW, closeH);
        ctx.fill(closeX, closeY, closeX + closeW, closeY + closeH, closeHov ? 0xDDC41E44 : 0xAA5A1224);
        drawBorder(ctx, closeX, closeY, closeW, closeH, 0xFFFFD466);
        ctx.drawCenteredTextWithShadow(this.textRenderer, "Close", closeX + closeW / 2, closeY + 6, 0xFFFFFF);

        // Render Module Cards
        for (ModuleCard c : cards) {
            boolean on = c.getter().getAsBoolean();
            boolean hov = isHover(mouseX, mouseY, c.x(), c.y(), c.w(), c.h());
            int cardBg = on ? (hov ? 0xCC24121C : 0xBB190E16) : (hov ? 0xAA191722 : 0x99100F16);
            int cardBrd = hov ? 0xFFFFD466 : (on ? 0xFFC41E44 : 0x33FFFFFF);
            ctx.fill(c.x(), c.y(), c.x() + c.w(), c.y() + c.h(), cardBg);
            drawBorder(ctx, c.x(), c.y(), c.w(), c.h(), cardBrd);

            // Left accent bar when ON
            if (on) ctx.fill(c.x(), c.y() + 4, c.x() + 2, c.y() + c.h() - 4, 0xFFFFD466);

            ctx.drawTextWithShadow(this.textRenderer, c.name(), c.x() + 8, c.y() + 6, on ? 0xFFFFFF : 0xAAAAAA);
            ctx.drawText(this.textRenderer, c.desc(), c.x() + 8, c.y() + 18, 0xFF887E90, false);

            // Sleek Pill Switch on right
            int sw = 24, sh = 11;
            int sx = c.x() + c.w() - sw - 8;
            int sy = c.y() + (c.h() - sh) / 2;
            ctx.fill(sx, sy, sx + sw, sy + sh, on ? 0xFF28A745 : 0xFF2A2633);
            drawBorder(ctx, sx, sy, sw, sh, on ? 0xFFFFD466 : 0x55FFFFFF);
            int knobX = on ? (sx + sw - 9) : (sx + 2);
            ctx.fill(knobX, sy + 2, knobX + 7, sy + sh - 2, on ? 0xFFFFD466 : 0xFF888899);
        }
    }

    private boolean isHover(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    private void drawBorder(DrawContext ctx, int x, int y, int w, int h, int color) {
        ctx.fill(x, y, x + w, y + 1, color);
        ctx.fill(x, y + h - 1, x + w, y + h, color);
        ctx.fill(x, y, x + 1, y + h, color);
        ctx.fill(x + w - 1, y, x + w, y + h, color);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
