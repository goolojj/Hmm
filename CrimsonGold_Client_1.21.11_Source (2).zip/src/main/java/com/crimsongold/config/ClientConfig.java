package com.crimsongold.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class ClientConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance().getConfigDir().resolve("crimsongold-client.json");

    public boolean hitboxEnabled = true;
    public boolean fpsBoostEnabled = true;
    public boolean outlineEnabled = true;
    public boolean motionBlurEnabled = true;
    public int motionBlurLevel = 2; // 1=Low, 2=Med, 3=High

    public boolean toggleSprintEnabled = true;
    public boolean fullbrightEnabled = true;
    public boolean noHurtCamEnabled = true;
    public boolean hudEnabled = true;
    public boolean keystrokesEnabled = true;
    public boolean armorHudEnabled = true;
    public boolean cpsCounterEnabled = true;
    public boolean sprintPillEnabled = true;

    public static ClientConfig load() {
        if (Files.exists(CONFIG_PATH)) {
            try {
                ClientConfig loaded = GSON.fromJson(Files.readString(CONFIG_PATH), ClientConfig.class);
                if (loaded != null) return loaded;
            } catch (Exception ignored) {
            }
        }
        ClientConfig cfg = new ClientConfig();
        cfg.save();
        return cfg;
    }

    public void save() {
        try {
            Files.writeString(CONFIG_PATH, GSON.toJson(this));
        } catch (IOException ignored) {
        }
    }
}
