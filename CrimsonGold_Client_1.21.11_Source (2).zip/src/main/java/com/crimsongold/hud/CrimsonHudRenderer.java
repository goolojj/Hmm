package com.crimsongold.hud;

import com.crimsongold.CrimsonGoldClient;
import com.crimsongold.config.ClientConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.EntityHitResult;

public class CrimsonHudRenderer {
    private static float prevYaw = 0f;
    private static float prevPitch = 0f;
    private static float smoothBlur = 0f;

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        ClientConfig cfg = CrimsonGoldClient.CONFIG;
        if (cfg == null) return;

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        // Smooth Exponential Motion Blur (clearly visible when turning!)
        if (cfg.motionBlurEnabled) {
            float yawDelta = Math.abs(mc.player.getYaw() - prevYaw);
            if (yawDelta > 180f) yawDelta = 360f - yawDelta;
            float pitchDelta = Math.abs(mc.player.getPitch() - prevPitch);
            float rawSpeed = Math.min(1.0f, (yawDelta + pitchDelta) / 14.0f);
            smoothBlur = smoothBlur * 0.78f + rawSpeed * 0.45f;
            if (smoothBlur > 0.02f) {
                float mult = cfg.motionBlurLevel == 1 ? 0.55f : (cfg.motionBlurLevel == 3 ? 1.45f : 1.0f);
                int alpha = Math.min(140, (int) (smoothBlur * mult * 95));
                // Layered speed-blur edges + soft center trail
                ctx.fill(0, 0, sw, sh, (alpha / 2 << 24) | 0x160912);
                int edgeW = Math.max(18, sw / 8);
                ctx.fill(0, 0, edgeW, sh, (alpha << 24) | 0x1A0A14);
                ctx.fill(sw - edgeW, 0, sw, sh, (alpha << 24) | 0x1A0A14);
            }
            prevYaw = mc.player.getYaw();
            prevPitch = mc.player.getPitch();
        }

        if (!cfg.hudEnabled) return;

        // Top-Left Feather Pill: FPS + Coords + CPS
        if (cfg.cpsCounterEnabled) {
            String fpsText = "§6FPS §f" + mc.getCurrentFps();
            String coords = String.format("§6XYZ §f%d %d %d",
                    (int) mc.player.getX(), (int) mc.player.getY(), (int) mc.player.getZ());
            String cpsText = "  §cCPS §f" + CrimsonGoldClient.getLeftCps() + " | " + CrimsonGoldClient.getRightCps();
            String line = fpsText + "  §8|  " + coords + cpsText;

            int boxW = mc.textRenderer.getWidth(line) + 12;
            ctx.fill(6, 6, 6 + boxW, 22, 0xBB0B0A10);
            drawBoxBorder(ctx, 6, 6, boxW, 16, 0xFFC41E44);
            ctx.drawTextWithShadow(mc.textRenderer, line, 12, 10, 0xFFFFFF);
        }

        // Target HUD Card (Top-Center when looking at entity)
        if (cfg.hitboxEnabled && mc.crosshairTarget instanceof EntityHitResult ehr) {
            Entity target = ehr.getEntity();
            int tw = 140;
            int tx = (sw - tw) / 2;
            int ty = 6;
            ctx.fill(tx, ty, tx + tw, ty + 28, 0xCC0C0A12);
            drawBoxBorder(ctx, tx, ty, tw, 28, 0xFFFFD466);

            String name = "§6" + target.getName().getString();
            String dist = String.format("§7%.1fm", mc.player.distanceTo(target));
            ctx.drawTextWithShadow(mc.textRenderer, name, tx + 6, ty + 5, 0xFFFFFF);
            ctx.drawTextWithShadow(mc.textRenderer, dist, tx + tw - mc.textRenderer.getWidth(dist) - 6, ty + 5, 0xFFFFFF);

            if (target instanceof LivingEntity le) {
                float pct = Math.max(0f, Math.min(1f, le.getHealth() / Math.max(1f, le.getMaxHealth())));
                int barW = tw - 12;
                ctx.fill(tx + 6, ty + 18, tx + 6 + barW, ty + 23, 0xFF22141C);
                ctx.fill(tx + 6, ty + 18, tx + 6 + (int) (barW * pct), ty + 23, 0xFFC41E44);
            }
        }

        // Keystrokes with SPACE bar
        if (cfg.keystrokesEnabled) {
            int kx = 6;
            int ky = 28;
            drawKey(ctx, mc, kx + 22, ky, 20, 18, "W", mc.options.forwardKey.isPressed());
            drawKey(ctx, mc, kx, ky + 20, 20, 18, "A", mc.options.leftKey.isPressed());
            drawKey(ctx, mc, kx + 22, ky + 20, 20, 18, "S", mc.options.backKey.isPressed());
            drawKey(ctx, mc, kx + 44, ky + 20, 20, 18, "D", mc.options.rightKey.isPressed());
            drawKey(ctx, mc, kx, ky + 40, 31, 16, "LMB", mc.options.attackKey.isPressed());
            drawKey(ctx, mc, kx + 33, ky + 40, 31, 16, "RMB", mc.options.useKey.isPressed());
            drawKey(ctx, mc, kx, ky + 58, 64, 12, "---", mc.options.jumpKey.isPressed());
        }

        // Bottom-Left ToggleSprint Pill
        if (cfg.sprintPillEnabled && cfg.toggleSprintEnabled) {
            String sp = mc.player.isSprinting() ? "§a[Sprinting (Toggled)]" : "§7[Sprint Ready]";
            int pw = mc.textRenderer.getWidth(sp) + 10;
            ctx.fill(6, sh - 20, 6 + pw, sh - 6, 0xAA0B0A10);
            drawBoxBorder(ctx, 6, sh - 20, pw, 14, 0x88FFD466);
            ctx.drawTextWithShadow(mc.textRenderer, sp, 11, sh - 17, 0xFFFFFF);
        }

        // Armor HUD (Bottom-Right)
        if (cfg.armorHudEnabled) {
            int ax = sw - 24;
            int ay = sh - 22;
            EquipmentSlot[] slots = {EquipmentSlot.FEET, EquipmentSlot.LEGS, EquipmentSlot.CHEST, EquipmentSlot.HEAD};
            for (EquipmentSlot slot : slots) {
                ItemStack stack = mc.player.getEquippedStack(slot);
                if (!stack.isEmpty()) {
                    ctx.drawItem(stack, ax, ay);
                    ctx.drawStackOverlay(mc.textRenderer, stack, ax, ay);
                }
                ay -= 18;
            }
        }
    }

    private static void drawKey(DrawContext ctx, MinecraftClient mc, int x, int y, int w, int h, String label, boolean pressed) {
        int bg = pressed ? 0xCCFFD466 : 0xB00B0A10;
        int border = pressed ? 0xFFFFFFFF : 0xFFC41E44;
        int txtCol = pressed ? 0xFF100810 : 0xFFFFFFFF;
        ctx.fill(x, y, x + w, y + h, bg);
        drawBoxBorder(ctx, x, y, w, h, border);
        int tw = mc.textRenderer.getWidth(label);
        ctx.drawText(mc.textRenderer, label, x + (w - tw) / 2, y + (h - 8) / 2, txtCol, false);
    }

    private static void drawBoxBorder(DrawContext ctx, int x, int y, int w, int h, int color) {
        ctx.fill(x, y, x + w, y + 1, color);
        ctx.fill(x, y + h - 1, x + w, y + h, color);
        ctx.fill(x, y, x + 1, y + h, color);
        ctx.fill(x + w - 1, y, x + w, y + h, color);
    }
}
